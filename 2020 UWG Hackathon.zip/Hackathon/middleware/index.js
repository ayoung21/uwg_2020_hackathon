var Resource = require("../models/resource");

var middlewareObj = {};

middlewareObj.checkResourceOwnership = function(req, res, next) {
    if (req.isAuthenticated()) {
        Resource.findById(req.params.id, function(err, foundResource) {
            if (err) {
                res.redirect('back');
            } else {
                // does user own resource?
                if (foundResource.author.id.equals(req.user._id)) {
                    next();
                } else {
                    res.redirect('back');
                }
            }
        })
    } else {
        // takes user back to the previous page
        res.redirect("back");
    }
}

middlewareObj.isLoggedIn = function(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }
    // req.flash("error", "Please Login First");
    res.redirect("/login");
}

module.exports = middlewareObj;