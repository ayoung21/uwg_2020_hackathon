var mongoose = require("mongoose");

// SCHEMA SETUP
var resourceSchema = new mongoose.Schema({
    name: String,
    url: String,
    isbn: String,
    image: String,
    description: String,
    type: String,
    category: String
});

module.exports = mongoose.model("Resource", resourceSchema);