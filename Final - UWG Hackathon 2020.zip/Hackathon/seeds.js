var mongoose = require("mongoose");
var Resource = require("./models/resource");
// var Comment   = require("./models/comment");

var data = [
    {
        name: "Soils Lab Manual", 
        image: "lab-manual.png",
        description: "The Soils Laboratory Manual, K-State Edition is designed for students in undergraduate, introductory soil science courses, and highlights the many aspects of soil science.",
        isbn: "978-1-944548-09-4",
        type: "book",
        url: "https://open.umn.edu/opentextbooks/textbooks/soils-laboratory-manual-k-state-edition",
        category: "science"
    },
    {
        name: "Entrepreneurship", 
        image: "entre.png",
        description: "This textbook is intended for use in introductory Entrepreneurship classes at the undergraduate level. ",
        isbn: "1-947172-70-0",
        type: "book",
        url: "https://openstax.org/details/books/entrepreneurship",
        category: "business"
    },
    {
        name: "Anatomy and Physiology", 
        image: "anatomy.png",
        description: "Anatomy and Physiology is a dynamic textbook for the two-semester human anatomy and physiology course for life science and allied health majors.",
        isbn: "1-947172-04-2",
        type: "book",
        url: "https://openstax.org/details/books/anatomy-and-physiology",
        category: "biology"
    },
    {
        name: "Algebra and Trigonometry", 
        image: "algebra.png",
        description: "Algebra and Trigonometry provides a comprehensive exploration of algebraic principles and meets scope and sequence requirements for a typical introductory algebra and trigonometry course.h",
        type: "book",
        url: "https://openstax.org/details/books/algebra-and-trigonometry",
        category: "math"
    },
    {
        name: "The Philosophy and Practices that are Revolutionizing Education and Science.", 
        image: "philosophy.png",
        description: "These ideals are slowly becoming a reality thanks to the open education, open science, and open access movements.",
        type: "book",
        url: "https://www.ubiquitypress.com/site/books/10.5334/bbc/",
        category: "philosophy"
    },
//
    {
        name: "Music and the Child", 
        image: "music.png",
        description: "Children are inherently musical. They respond to music and learn through music.",
        type: "book",
        url: "https://textbooks.opensuny.org/music-and-the-child/",
        category: "music"
    }
]

function seedDB(){
   //Remove all resources
   Resource.remove({}, function(err){
        if(err){
            console.log(err);
        }
        console.log("removed resources!");
         //add a few resources
        data.forEach(function(seed){
            Resource.create(seed, function(err, resource){
                if(err){
                    console.log(err)
                } else {
                    console.log("added a resource");
                    resource.save();
                }
            });
        });
    }); 
}

module.exports = seedDB;