var express    = require("express"),
    app        = express(),
    bodyParser = require("body-parser"),
    mongoose   = require("mongoose"),
    User       = require("./models/user"),
    Resource   = require("./models/resource"),
    passport   = require("passport"),
    LocalStrategy = require("passport-local"),
    methodOverride = require("method-override"),
    middleware = require("./middleware"),
    seedDB     = require("./seeds.js");

mongoose.connect("mongodb://localhost/oer_v1", {
    useNewUrlParser: true,
    useUnifiedTopology: true
}, function() {
    console.log("DB Started...");
});

app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs");

app.use(express.static(__dirname + "/public"));
app.use(methodOverride("_method"));

// PASSPORT CONFIGURATION
app.use(require("express-session")({
    secret: "Once again Rusty wins cutest dog!",
    resave: false,
    saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

app.use(function(req, res, next){
    res.locals.currentUser = req.user;
    next();
 });

 seedDB();

/*
var resources = [
    {name: "Salmon Creek", image: "https://farm9.staticflickr.com/8442/7962474612_bf2baf67c0.jpg"},
    {name: "Granite Hill", image: "https://farm1.staticflickr.com/60/215827008_6489cd30c3.jpg"},
    {name: "Mountain Goat's Rest", image: "https://farm7.staticflickr.com/6057/6234565071_4d20668bbd.jpg"},
    {name: "Salmon Creek", image: "https://farm9.staticflickr.com/8442/7962474612_bf2baf67c0.jpg"},
    {name: "Granite Hill", image: "https://farm1.staticflickr.com/60/215827008_6489cd30c3.jpg"},
    {name: "Mountain Goat's Rest", image: "https://farm7.staticflickr.com/6057/6234565071_4d20668bbd.jpg"},
    {name: "Salmon Creek", image: "https://farm9.staticflickr.com/8442/7962474612_bf2baf67c0.jpg"},
    {name: "Granite Hill", image: "https://farm1.staticflickr.com/60/215827008_6489cd30c3.jpg"},
    {name: "Mountain Goat's Rest", image: "https://farm7.staticflickr.com/6057/6234565071_4d20668bbd.jpg"}
];
*/

// Remove after initial start
/*
Resource.create(
      {
          name: "Granite Hill", 
          image: "https://farm1.staticflickr.com/60/215827008_6489cd30c3.jpg",
          description: "This is a huge granite hill, no bathrooms.  No water. Beautiful granite!"
         
      },
      function(err, resource){
        if(err){
            console.log(err);
        } else {
            console.log("NEWLY CREATED RESOURCE: ");
            console.log(resource);
        }
});
*/

app.get("/", function(req, res){
    res.render("landing");
});

app.get("/resources", function(req, res){
    var noMatch = null;

    if (req.query.search) {
        const regex = new RegExp(escapeRegex(req.query.search), 'gi');
        // Get all resources from DB
        Resource.find({category: regex}, function(err, allResources){
        if (err){
            console.log(err);
        } else {
            if (allResources.length < 1) {
                noMatch = "No resources match that query";
            }
            res.render("index",{resources:allResources, noMatch: noMatch});
        }
    });
    } else {
        // Get all resources from DB
        Resource.find({}, function(err, allResources){
            if (err){
                console.log(err);
            } else {
                res.render("index",{resources:allResources, noMatch: noMatch});
                console.log("URL: ");
            }
        });
    }

});

app.post("/resources", middleware.isLoggedIn, function(req, res){
    // get data from form and add to resources array
    var name  = req.body.name;
    var image = req.body.image;
    var desc  = req.body.description;
    var url   = req.body.url;
    var isbn  = req.body.isbn;
    var type  = req.body.type;

    var newResource = {name: name, image: image, isbn: isbn, url: url, description: desc, type: type}
    // Create a new resource and save to DB
    Resource.create(newResource, function(err, newlyCreated){
        if(err){
            console.log(err);
        } else {
            //redirect back to resources page
            res.redirect("/resources");
        }
    });
});

app.get("/resources/new", middleware.isLoggedIn, function(req, res){
   res.render("new"); 
});

// SHOW - shows more info about one campground
/*
app.get("/resources/:id", function(req, res){
    //find the campground with provided ID
    Resource.findById(req.params.id, function(err, foundResource){
        if(err){
            console.log(err);
        } else {
            //render show template with that campground
            res.render("show", {resource: foundResource});
        }
    });
})
*/

//  ===========
// AUTH ROUTES
//  ===========

// show register form
app.get("/register", function(req, res){
    res.render("register"); 
 });
 //handle sign up logic
 app.post("/register", function(req, res){
     var newUser = new User({username: req.body.username});
     User.register(newUser, req.body.password, function(err, user){
         if(err){
             console.log(err);
             return res.render("register");
         }
         passport.authenticate("local")(req, res, function(){
            res.redirect("/resources"); 
         });
     });
 });
 
 // show login form
 app.get("/login", function(req, res){
    res.render("login"); 
 });
 // handling login logic
 app.post("/login", passport.authenticate("local", 
     {
         successRedirect: "/resources",
         failureRedirect: "/login"
     }), function(req, res){
 });
 
 // logic route
 app.get("/logout", function(req, res){
    req.logout();
    res.redirect("/resources");
 });
 
 function isLoggedIn(req, res, next){
     if(req.isAuthenticated()){
         return next();
     }
     res.redirect("/login");
 }

 function escapeRegex(text) {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
};

app.listen(3000, function(){
   console.log("The YelpCamp Server Has Started!");
});
